import java.util.Scanner;

public class medad {

	public static void main(String args[]) {
		
		Scanner s = new Scanner(System.in);
		int edad;
		String nombre;
		
		do {
			System.out.println("Ingrese su nombre.");
			nombre = s.next();
			
			System.out.println("Por favor, indique su edad");
			edad = s.nextInt();
			if (edad>18) {
				System.out.println(nombre + ", usted es mayor de edad");
			} else if (edad>0 && edad<18)  {
				System.out.println(nombre + ", usted es menor de edad");
			}
			
		}while(edad>0);
		
		System.out.println("No se puede ingresar como edad CERO.");
		
		
		
		
	}
	
}
