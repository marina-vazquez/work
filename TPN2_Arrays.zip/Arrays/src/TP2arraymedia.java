import java.util.Scanner;

public class TP2arraymedia {

	
	public static void main(String args[]) {
		
	Scanner s = new Scanner(System.in);
	
	int [] enteros = new int [10];
	int i;
	double media = 0;
	
	for (i=0;i<enteros.length; i++) {
		System.out.printf("Ingrese un numero entero : ");
		enteros[i] = s.nextInt();
		
	}
	
	for (i=0;i<10;i++) {
		if (i % 2 == 0) {
			media = media + enteros[i];
		}
		
	}
	System.out.println("La media de las posiciones pares es: " + media/5);
	
	
	
	
		}
		
	}