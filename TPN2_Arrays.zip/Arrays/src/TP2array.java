import java.util.Scanner;

public class TP2array {
	
	public static void main(String args[]) {
		
	Scanner s = new Scanner(System.in);
	
	int [] enteros = new int [10];
	int i;
	int n=0, c=0, p=0;
	
	for (i=0;i<enteros.length; i++) {
		System.out.printf("Ingrese un numero entero : ");
		enteros[i] = s.nextInt();
	if (enteros[i]<0) {
		n++;
	}
	if (enteros[i]==0) {
		c++;
	}
	if (enteros[i]>0) {
		p++;
	}
		
	} 
	System.out.printf("\nLos numeros negativos ingresados son: %d", n);
	System.out.printf("\nLos numeros positivos ingresados son: %d", p);
	System.out.printf("\nLa cantidad de ceros ingresados es: %d", c);
		
		
		
	}

}
